public enum SoundType
{
    SuccessCatch, LostCatch, RodCast, RodBack, PullSound
}
